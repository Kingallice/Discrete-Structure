package largest.prime.factor;

import java.math.BigInteger;

public class LargestPrimeFactor 
{
    BigInteger a;
    public static void main(String[] args) 
    {
        LarPriFactor(new BigInteger("13195"));
    }
    public static long LarPriFactor(BigInteger num)
    {
        boolean factorRemains = true;
        int i = 1;
        while(factorRemains)
        {
            i++;
            if(num.intValue()%i == 0)
            {
                int j = 1;
                while(i%j != 0)
                {
                    if(i%j == 0)
                    {
                        System.out.println(j + " is prime");
                    }
                    j++;
                }
            }
        }
        return i;
    }
}
